# Movie Trailer site
 
===============================================================================
Displays a set of Movies on the page. One can view the trailer of a movie by clicking on the Movie box art image

# Install
===============================================================================
Python 2.7 or higher must be installed.
Install the Movie Trailer site using the following command:
git clone https://github.com/scharati/ud036_StarterCode.git

# Usage
===============================================================================
Run the following command in a command prompt [python executable should be available in system path]

py movies\entertainment_center.py

This should open the Movie Trailer site with the given set of movies. Clicking on any movie tile should play the 
movie trailer